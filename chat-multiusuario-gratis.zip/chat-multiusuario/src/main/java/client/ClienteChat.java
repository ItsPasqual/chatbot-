package client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Cliente de console. Duas threads: a principal lê o teclado e envia;
 * outra lê do socket e imprime. Só conhece a rede.
 * Uso: ClienteChat [host] [porta]
 */
public class ClienteChat {

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;

        PrintStream console = new PrintStream(System.out, true, StandardCharsets.UTF_8);

        try (Socket socket = new Socket(host, porta)) {
            BufferedReader doServidor = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter paraServidor = new PrintWriter(new OutputStreamWriter(
                    socket.getOutputStream(), StandardCharsets.UTF_8), true);
            BufferedReader teclado = new BufferedReader(
                    new InputStreamReader(System.in, StandardCharsets.UTF_8));

            Thread leitor = new Thread(() -> {
                try {
                    String linha;
                    while ((linha = doServidor.readLine()) != null) {
                        console.println(linha);
                    }
                } catch (IOException e) {
                    // conexão encerrada
                }
                console.println("* Conexão encerrada.");
                System.exit(0);
            }, "leitor-socket");
            leitor.setDaemon(true);
            leitor.start();

            String linha;
            while ((linha = teclado.readLine()) != null) {
                paraServidor.println(linha);
                if (linha.trim().equalsIgnoreCase("/quit")) {
                    break;
                }
            }
        } catch (IOException e) {
            console.println("Não foi possível conectar a " + host + ":" + porta + " - " + e.getMessage());
        }
    }
}
