package client;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cliente com janela temática (Swing). Só conhece a rede (mesmo protocolo do ClienteChat).
 * A thread de rede NUNCA mexe nos componentes: tudo passa por SwingUtilities.invokeLater.
 * Uso: ClienteChatGui [host] [porta]
 */
public class ClienteChatGui {

    static final String NOME_BOT = "ChatBot";
    private static final Pattern MENSAGEM = Pattern.compile("^\\[(\\d{2}/\\d{2} \\d{2}:\\d{2})] (\\S+): (.*)$");

    /** Paleta de um tema visual. */
    record Tema(String nome, Color fundo, Color painel, Color texto, Color suave,
                Color proprio, Color textoProprio, Color outros,
                Color bot, Color nomeBot, Color destaque) {
    }

    static final List<Tema> TEMAS = List.of(
            new Tema("Noite", cor("#12121c"), cor("#1c1c2b"), cor("#e8e8f2"), cor("#8b8ba7"),
                    cor("#6c5ce7"), cor("#ffffff"), cor("#2a2a40"), cor("#0f3d3a"), cor("#5eead4"), cor("#6c5ce7")),
            new Tema("Pastel", cor("#fdf2f8"), cor("#ffffff"), cor("#3b3548"), cor("#9a8fa8"),
                    cor("#f9a8d4"), cor("#4a1d3a"), cor("#ede9fe"), cor("#d1fae5"), cor("#047857"), cor("#ec4899")),
            new Tema("Oceano", cor("#0b1e2d"), cor("#12324a"), cor("#e6f4fa"), cor("#7fa8bf"),
                    cor("#0ea5e9"), cor("#ffffff"), cor("#17405e"), cor("#0d6b63"), cor("#fde68a"), cor("#0ea5e9")));

    private static final String[][] PERGUNTAS_RAPIDAS = {
            {"Requisitos", "@bot quais são os requisitos?"},
            {"Concorrência", "@bot como funciona a concorrência?"},
            {"Banco de dados", "@bot como funciona o banco de dados?"},
            {"Testes", "@bot quais testes existem?"},
            {"Ajuda", "@bot ajuda"}
    };

    private final String host;
    private final int porta;
    private final List<String> linhas = new ArrayList<>(); // só acessada na thread do Swing
    private Tema temaAtual = TEMAS.get(0);
    private String nickAtual = "";

    private JFrame janela;
    private JPanel cabecalho;
    private JPanel sul;
    private JPanel painelChips;
    private JPanel rodape;
    private JLabel titulo;
    private JLabel subtitulo;
    private JComboBox<String> seletorTema;
    private JEditorPane editor;
    private JScrollPane rolagem;
    private JTextField campoMensagem;
    private JButton botaoEnviar;
    private final List<JButton> chips = new ArrayList<>();

    private Socket socket;
    private PrintWriter saida;
    private volatile boolean encerrado;

    public ClienteChatGui(String host, int porta) {
        this.host = host;
        this.porta = porta;
    }

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;
        SwingUtilities.invokeLater(() -> new ClienteChatGui(host, porta).iniciar());
    }

    // ------------------------------------------------------------ montagem da janela

    private void iniciar() {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            // segue com o visual padrão
        }
        construirJanela();
        aplicarTema();

        String nickname = pedirNickname("Digite seu nickname:");
        if (nickname == null) {
            System.exit(0);
        }
        try {
            conectar(nickname);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,
                    "Não foi possível conectar a " + host + ":" + porta
                            + "\nO servidor está rodando?\n\n" + e.getMessage(),
                    "Erro de conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        janela.setVisible(true);
        campoMensagem.requestFocusInWindow();
    }

    private void construirJanela() {
        janela = new JFrame("Chat Multiusuário");
        janela.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        janela.setSize(560, 700);
        janela.setMinimumSize(new java.awt.Dimension(420, 480));
        janela.setLocationByPlatform(true);

        // cabeçalho
        titulo = new JLabel("Chat Multiusuário");
        titulo.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        subtitulo = new JLabel("conectando...");
        subtitulo.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        JPanel textos = new JPanel(new BorderLayout());
        textos.setOpaque(false);
        textos.add(titulo, BorderLayout.NORTH);
        textos.add(subtitulo, BorderLayout.SOUTH);

        seletorTema = new JComboBox<>(TEMAS.stream().map(Tema::nome).toArray(String[]::new));
        seletorTema.addActionListener(e -> {
            temaAtual = TEMAS.get(seletorTema.getSelectedIndex());
            aplicarTema();
        });
        JPanel direita = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        direita.setOpaque(false);
        direita.add(new JLabel("Tema: "));
        direita.add(seletorTema);

        cabecalho = new JPanel(new BorderLayout());
        cabecalho.setBorder(new EmptyBorder(12, 16, 12, 16));
        cabecalho.add(textos, BorderLayout.CENTER);
        cabecalho.add(direita, BorderLayout.EAST);

        // conversa
        editor = new JEditorPane();
        editor.setContentType("text/html");
        editor.setEditable(false);
        rolagem = new JScrollPane(editor);
        rolagem.setBorder(null);

        // perguntas rápidas para o bot
        painelChips = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 6));
        for (String[] p : PERGUNTAS_RAPIDAS) {
            JButton chip = new JButton(p[0]);
            chip.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
            chip.addActionListener(e -> enviarTexto(p[1]));
            chips.add(chip);
            painelChips.add(chip);
        }

        // entrada
        campoMensagem = new JTextField();
        campoMensagem.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        campoMensagem.addActionListener(e -> enviar());
        botaoEnviar = new JButton("Enviar");
        botaoEnviar.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 13));
        botaoEnviar.addActionListener(e -> enviar());

        rodape = new JPanel(new BorderLayout(8, 0));
        rodape.setBorder(new EmptyBorder(4, 10, 12, 10));
        rodape.add(campoMensagem, BorderLayout.CENTER);
        rodape.add(botaoEnviar, BorderLayout.EAST);

        sul = new JPanel(new BorderLayout());
        sul.add(painelChips, BorderLayout.NORTH);
        sul.add(rodape, BorderLayout.CENTER);

        janela.add(cabecalho, BorderLayout.NORTH);
        janela.add(rolagem, BorderLayout.CENTER);
        janela.add(sul, BorderLayout.SOUTH);

        janela.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                sair();
            }
        });
    }

    private void aplicarTema() {
        Tema t = temaAtual;
        cabecalho.setBackground(t.painel());
        titulo.setForeground(t.texto());
        subtitulo.setForeground(t.suave());
        for (java.awt.Component c : ((JPanel) cabecalho.getComponent(1)).getComponents()) {
            c.setForeground(t.texto());
        }
        seletorTema.setBackground(t.fundo());
        seletorTema.setForeground(t.texto());

        sul.setBackground(t.painel());
        painelChips.setBackground(t.painel());
        rodape.setBackground(t.painel());
        for (JButton chip : chips) {
            estilizar(chip, t.outros(), t.texto(), 5, 12);
        }
        estilizar(botaoEnviar, t.destaque(), Color.WHITE, 9, 20);

        campoMensagem.setBackground(t.fundo());
        campoMensagem.setForeground(t.texto());
        campoMensagem.setCaretColor(t.texto());
        campoMensagem.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(t.suave(), 1), new EmptyBorder(8, 10, 8, 10)));

        editor.setBackground(t.fundo());
        rolagem.getViewport().setBackground(t.fundo());
        renderizar();
    }

    private static void estilizar(JButton b, Color fundo, Color texto, int vertical, int horizontal) {
        b.setBackground(fundo);
        b.setForeground(texto);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(vertical, horizontal, vertical, horizontal));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    // ------------------------------------------------------------ HTML da conversa

    private void renderizar() {
        editor.setText(montarHtml(linhas, nickAtual, temaAtual));
        editor.setCaretPosition(editor.getDocument().getLength());
    }

    /** Converte as linhas do protocolo em HTML com balões. Estático para ser testável. */
    static String montarHtml(List<String> linhas, String nick, Tema t) {
        StringBuilder h = new StringBuilder();
        h.append("<html><body style=\"font-family:SansSerif; font-size:13pt; color:").append(hex(t.texto()))
                .append("; background-color:").append(hex(t.fundo())).append("; margin:6px\">");
        for (String linha : linhas) {
            Matcher m = MENSAGEM.matcher(linha);
            if (m.matches()) {
                h.append(balao(m.group(2), m.group(1), m.group(3), nick, t));
            } else if (linha.startsWith("* ")) {
                h.append("<table width=\"100%\" cellpadding=\"4\"><tr><td align=\"center\"><font size=\"2\" color=\"")
                        .append(hex(t.suave())).append("\"><i>").append(esc(linha.substring(2)))
                        .append("</i></font></td></tr></table>");
            } else {
                h.append("<div>").append(esc(linha)).append("</div>");
            }
        }
        return h.append("</body></html>").toString();
    }

    private static String balao(String nome, String hora, String texto, String nick, Tema t) {
        boolean proprio = nome.equalsIgnoreCase(nick);
        boolean bot = nome.equalsIgnoreCase(NOME_BOT);
        Color fundo = proprio ? t.proprio() : bot ? t.bot() : t.outros();
        Color corTexto = proprio ? t.textoProprio() : t.texto();
        Color corNome = proprio ? t.textoProprio() : bot ? t.nomeBot() : t.destaque();
        Color corHora = proprio ? t.textoProprio() : t.suave();
        String rotulo = proprio ? "Você" : bot ? esc(nome) + " · bot" : esc(nome);

        String miolo = "<table width=\"100%\" cellpadding=\"8\" cellspacing=\"0\" bgcolor=\"" + hex(fundo) + "\"><tr><td>"
                + "<font color=\"" + hex(corNome) + "\"><b>" + rotulo + "</b></font> "
                + "<font size=\"2\" color=\"" + hex(corHora) + "\">" + hora + "</font><br>"
                + "<font color=\"" + hex(corTexto) + "\">" + esc(texto) + "</font>"
                + "</td></tr></table>";
        String espaco = "<td width=\"22%\"></td>";
        return "<table width=\"100%\" cellpadding=\"0\" cellspacing=\"4\"><tr>"
                + (proprio ? espaco + "<td>" + miolo + "</td>" : "<td>" + miolo + "</td>" + espaco)
                + "</tr></table>";
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    private static String hex(Color c) {
        return String.format("#%02x%02x%02x", c.getRed(), c.getGreen(), c.getBlue());
    }

    private static Color cor(String hex) {
        return Color.decode(hex);
    }

    // ------------------------------------------------------------ rede

    private String pedirNickname(String texto) {
        return JOptionPane.showInputDialog(janela, texto, "Entrar no chat", JOptionPane.QUESTION_MESSAGE);
    }

    private void conectar(String nickname) throws IOException {
        nickAtual = nickname;
        socket = new Socket(host, porta);
        BufferedReader doServidor = new BufferedReader(
                new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        saida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
        saida.println(nickname);

        Thread leitor = new Thread(() -> {
            try {
                String linha;
                while ((linha = doServidor.readLine()) != null) {
                    String recebida = linha;
                    SwingUtilities.invokeLater(() -> tratarLinha(recebida));
                }
            } catch (IOException e) {
                // conexão encerrada
            }
            SwingUtilities.invokeLater(this::conexaoEncerrada);
        }, "leitor-socket");
        leitor.setDaemon(true);
        leitor.start();
    }

    /** Executa na thread do Swing. */
    private void tratarLinha(String linha) {
        if (linha.startsWith("* Bem-vindo")) {
            return; // o nickname já foi enviado
        }
        adicionar(linha);
        if (linha.endsWith("Tente outro nickname:")) {
            String novo = pedirNickname(linha.substring(2));
            if (novo == null) {
                sair();
            } else {
                nickAtual = novo;
                saida.println(novo);
            }
        } else if (linha.startsWith("* Digite suas mensagens")) {
            janela.setTitle("Chat Multiusuário - " + nickAtual);
            subtitulo.setText("online como " + nickAtual);
            renderizar();
        }
    }

    private void enviar() {
        enviarTexto(campoMensagem.getText());
        campoMensagem.setText("");
    }

    private void enviarTexto(String texto) {
        if (encerrado || texto == null || texto.isBlank()) {
            return;
        }
        saida.println(texto.trim());
        if (saida.checkError()) {
            conexaoEncerrada();
        }
        campoMensagem.requestFocusInWindow();
    }

    private void adicionar(String linha) {
        linhas.add(linha);
        renderizar();
    }

    private void conexaoEncerrada() {
        if (encerrado) {
            return;
        }
        encerrado = true;
        subtitulo.setText("desconectado");
        adicionar("* Conexão encerrada.");
        campoMensagem.setEnabled(false);
        botaoEnviar.setEnabled(false);
        chips.forEach(c -> c.setEnabled(false));
    }

    private void sair() {
        try {
            if (saida != null && !encerrado) {
                saida.println("/quit");
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            // saindo mesmo assim
        }
        janela.dispose();
        System.exit(0);
    }
}
