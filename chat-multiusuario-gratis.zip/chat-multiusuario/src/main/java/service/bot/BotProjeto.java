package service.bot;

import model.Usuario;

import java.text.Normalizer;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Bot por palavras-chave que responde sobre o próprio projeto (requisitos, arquitetura,
 * concorrência, banco, testes...). Sem IA externa e sem estado: é seguro entre threads.
 */
public class BotProjeto implements Bot {

    public static final Usuario USUARIO = new Usuario("ChatBot");

    private record Topico(List<String> raizes, String resposta) {
    }

    private static final String AJUDA = "Pergunte sobre: requisitos, arquitetura, concorrência, "
            + "race conditions, broadcast, banco/JDBC, testes, protocolo, desconexão, nickname, "
            + "critérios, cronograma, relatório ou extras. Use @bot antes da pergunta.";

    private static final Set<String> SAUDACOES = Set.of("oi", "ola", "opa", "eai", "salve", "hello", "hi", "hey");

    // A ordem importa: em caso de empate de pontos vence o tópico que vem primeiro.
    private static final List<Topico> TOPICOS = List.of(
            new Topico(List.of("requisit", "obrigat"),
                    "Requisitos obrigatórios: Servidor com ServerSocket e laço de accept(), uma thread por conexão, "
                            + "ClienteHandler (Runnable), coleção sincronizada de clientes, broadcast, classe Mensagem, "
                            + "persistência JDBC com Repository, histórico ao conectar, desconexão segura, "
                            + "mínimo de 5 testes JUnit sem rede e código organizado em pacotes."),
            new Topico(List.of("arquitet", "pacote", "camada", "estrutur"),
                    "Arquitetura em camadas: model (Usuario, Mensagem), persistence (Repository + jdbc), "
                            + "service (ChatService, ClientRegistry), server (Servidor, ClienteHandler) e client. "
                            + "Regra: Socket não conhece SQL, Repository não conhece socket, Model não conhece nenhum "
                            + "dos dois e o Service conecta as partes."),
            new Topico(List.of("concorr", "thread", "paralel", "simultane", "multithread"),
                    "Uma thread por cliente (ClienteHandler). O estado compartilhado fica no ClientRegistry "
                            + "(CopyOnWriteArrayList), o broadcast usa um snapshot da lista e enviar() é synchronized "
                            + "para não misturar linhas. Mensagem e Usuario são imutáveis e cada operação JDBC abre "
                            + "a sua própria Connection."),
            new Topico(List.of("race", "sincroniz", "synchronized", "lock", "atomic", "condition"),
                    "Race conditions tratadas: nickname duplicado (check-then-act atômico no ClientRegistry.adicionar) "
                            + "e ordem salvar x broadcast (seção crítica única no ChatService.enviarMensagem), assim o "
                            + "histórico do banco bate com o que todos viram. Trade-off: menos paralelismo."),
            new Topico(List.of("broadcast", "transmit", "retransm"),
                    "Broadcast: o ChatService pega um snapshot do ClientRegistry e chama enviar() em cada "
                            + "ConexaoCliente, sem segurar lock durante a escrita. Se o envio falhar para alguém, só "
                            + "aquele cliente é removido e os outros continuam recebendo."),
            new Topico(List.of("banco", "jdbc", "h2", "sql", "persist", "repository", "histor"),
                    "Persistência: o JdbcMensagemRepository usa PreparedStatement e try-with-resources, uma Connection "
                            + "por operação, e grava cada mensagem na tabela mensagem (H2) antes do broadcast. "
                            + "Ao conectar, o cliente recebe as últimas N mensagens em ordem cronológica."),
            new Topico(List.of("test", "junit", "tdd"),
                    "Testes JUnit 5 sem rede real: UsuarioTest, MensagemTest, ClientRegistryTest (com concorrência), "
                            + "ChatServiceTest com FakeConexao e InMemoryMensagemRepository, e BotProjetoTest. "
                            + "O repository JDBC tem teste de integração com H2 em memória."),
            new Topico(List.of("protocolo", "utf", "encoding", "acento", "handshake", "comando"),
                    "Protocolo: texto, uma mensagem por linha, UTF-8 nos dois lados. A primeira linha do cliente é o "
                            + "nickname; linhas iniciadas por / são comandos (por enquanto só /quit); avisos do sistema "
                            + "começam com '* '."),
            new Topico(List.of("desconect", "desconex", "sair", "quit", "cai", "queda", "abrupt"),
                    "Desconexão segura: se o cliente sai com /quit ou cai, o readLine() devolve null ou lança exceção, "
                            + "o finally do ClienteHandler chama ChatService.desconectar(), remove do registry, avisa "
                            + "a saída e fecha o socket, sem afetar o servidor nem os outros clientes."),
            new Topico(List.of("nick", "apelido"),
                    "Nickname: sem espaços, até 30 caracteres e único (sem distinguir maiúsculas). A verificação é "
                            + "atômica no ClientRegistry. O nome ChatBot é reservado."),
            new Topico(List.of("criterio", "nota", "ponto", "avalia"),
                    "Critérios (5,0 pts): multithreading correto 1,3; broadcast sem perder mensagens 1,2; "
                            + "persistência JDBC 1,0; pacotes e responsabilidades 0,5; testes unitários 0,5; "
                            + "organização e relatório 0,5. Concorrência e persistência valem 3,5 pontos."),
            new Topico(List.of("cronograma", "prazo", "semana"),
                    "Cronograma de 06/10 a 30/11/2026: semanas 1 a 4 formam o núcleo (domínio, cliente-servidor, "
                            + "broadcast, persistência), 5 a 7 são extras (comandos, busca, timeout) e a 8 é o "
                            + "congelamento: correções, testes, relatório e vídeo. Se atrasar, corte extras, nunca requisitos."),
            new Topico(List.of("relatori", "video", "entregav"),
                    "O relatório deve ter diagrama de pacotes e de classes, fluxo de uma mensagem, objetos "
                            + "compartilhados entre threads e como foram protegidos, ao menos uma race condition evitada, "
                            + "decisões de persistência e extras. O vídeo (3 a 5 min) mostra 3 clientes, o histórico "
                            + "e um cliente caindo sem afetar os demais."),
            new Topico(List.of("extra", "bonus", "sala", "privad", "autentic"),
                    "Extras possíveis (não valem pontos diretos): comandos /help e /users, mensagens privadas, busca "
                            + "no histórico, timeout de inatividade, salas, autenticação. Já feitos: avisos de entrada "
                            + "e saída, nickname único e este bot. Nunca à custa dos requisitos obrigatórios."),
            new Topico(List.of("ajuda", "help", "topico"), AJUDA),
            new Topico(List.of("voce", "chatbot"),
                    "Sou o ChatBot, um bot simples do projeto. Respondo por palavras-chave sobre requisitos, "
                            + "arquitetura, concorrência, banco, testes e cronograma. Minhas mensagens também são "
                            + "salvas no banco e transmitidas como as de qualquer usuário. Digite @bot ajuda.")
    );

    @Override
    public Usuario getUsuario() {
        return USUARIO;
    }

    /** Todo o conhecimento do bot em texto corrido; usado como contexto por bots com IA. */
    public String resumoDoProjeto() {
        return TOPICOS.stream().map(Topico::resposta).collect(Collectors.joining(" "));
    }

    @Override
    public Optional<String> responder(Usuario autor, String texto) {
        if (texto == null || autor.equals(USUARIO)) {
            return Optional.empty();
        }
        Set<String> palavras = tokenizar(texto);

        Topico melhor = null;
        int melhorPontos = 0;
        for (Topico topico : TOPICOS) {
            int pontos = 0;
            for (String raiz : topico.raizes()) {
                if (palavras.stream().anyMatch(p -> p.startsWith(raiz))) {
                    pontos++;
                }
            }
            if (pontos > melhorPontos) {
                melhor = topico;
                melhorPontos = pontos;
            }
        }
        if (melhor != null) {
            return Optional.of(melhor.resposta());
        }
        if (palavras.stream().anyMatch(SAUDACOES::contains)) {
            return Optional.of("Oi, " + autor.nome() + "! Sou o ChatBot e sei tudo sobre este projeto. "
                    + "Digite @bot ajuda para ver os assuntos.");
        }
        if (palavras.contains("bot") || palavras.contains("chatbot")) {
            return Optional.of("Não entendi. " + AJUDA);
        }
        return Optional.empty();
    }

    @Override
    public String boasVindas(Usuario novo) {
        return "Oi, " + novo.nome() + "! Sou o ChatBot. Pergunte sobre o projeto começando com @bot "
                + "(ex.: @bot como funciona a concorrência?) ou digite @bot ajuda.";
    }

    /** Minúsculas, sem acentos, separado em palavras. */
    private static Set<String> tokenizar(String texto) {
        String limpo = Normalizer.normalize(texto, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase();
        return Arrays.stream(limpo.split("[^a-z0-9]+"))
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toSet());
    }
}
