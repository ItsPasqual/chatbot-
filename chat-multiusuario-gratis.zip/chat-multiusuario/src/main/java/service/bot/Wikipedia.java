package service.bot;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/** Busca o início do artigo na Wikipedia em português. Gratuito, sem cadastro e sem chave. */
public class Wikipedia implements FonteConhecimento {

    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();

    @Override
    public Optional<String> resumo(String termo) throws IOException, InterruptedException {
        String url = "https://pt.wikipedia.org/w/api.php?action=query&generator=search&gsrlimit=1"
                + "&prop=extracts&exintro=1&explaintext=1&exsentences=2&redirects=1"
                + "&format=json&formatversion=2&gsrsearch=" + URLEncoder.encode(termo, StandardCharsets.UTF_8);
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("User-Agent", "chat-multiusuario/1.0 (projeto de faculdade)")
                .GET().build();
        HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (resp.statusCode() != 200) {
            throw new IOException("Wikipedia respondeu HTTP " + resp.statusCode());
        }
        return extrair(resp.body());
    }

    static Optional<String> extrair(String json) {
        if (!(Json.parse(json) instanceof Map<?, ?> raiz) || !(raiz.get("query") instanceof Map<?, ?> q)
                || !(q.get("pages") instanceof List<?> paginas) || paginas.isEmpty()
                || !(paginas.get(0) instanceof Map<?, ?> pagina)
                || !(pagina.get("extract") instanceof String extrato) || extrato.isBlank()) {
            return Optional.empty();
        }
        return Optional.of(extrato);
    }
}
