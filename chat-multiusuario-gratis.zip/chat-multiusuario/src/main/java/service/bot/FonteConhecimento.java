package service.bot;

import java.io.IOException;
import java.util.Optional;

/** Fonte de resumos sobre um assunto (ex.: Wikipedia). Pode demorar: é rede. */
public interface FonteConhecimento {

    Optional<String> resumo(String termo) throws IOException, InterruptedException;
}
