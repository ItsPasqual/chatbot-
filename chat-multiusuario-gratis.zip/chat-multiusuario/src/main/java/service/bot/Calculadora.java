package service.bot;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;

/** Calculadora segura (sem eval): + - * / ^ e parênteses. Aceita vírgula ou ponto decimal. */
final class Calculadora {

    private final String s;
    private int i;

    private Calculadora(String s) {
        this.s = s;
    }

    /** Vazio se o texto não parecer uma conta; mensagem de erro amigável se parecer mas não der. */
    static Optional<String> calcular(String texto) {
        String t = texto.toLowerCase()
                .replaceAll("^(quanto (e|é|vale|da|dá)|calcule|calcula|resultado de)\\s+", "")
                .replace('÷', '/').replace('×', '*')
                .replaceAll("(?<=[\\d)])\\s*x\\s*(?=[\\d(])", "*")
                .replaceAll("[?=\\s]+$", "")
                .trim();
        if (!t.matches("[0-9+\\-*/^().,\\s]+") || !t.matches(".*\\d.*") || !t.matches(".*[0-9)]\\s*[+*/^-].*")) {
            return Optional.empty();
        }
        try {
            Calculadora c = new Calculadora(t.replace(',', '.').replaceAll("\\s+", ""));
            double r = c.expressao();
            if (c.i != c.s.length()) {
                throw new IllegalArgumentException();
            }
            if (Double.isNaN(r) || Double.isInfinite(r)) {
                return Optional.of("Não dá para calcular isso (divisão por zero ou número grande demais).");
            }
            return Optional.of(t + " = " + formatar(r));
        } catch (RuntimeException e) {
            return Optional.of("Não consegui entender essa conta. Exemplo: @bot 12 * (3 + 4)");
        }
    }

    static String formatar(double v) {
        BigDecimal bd = BigDecimal.valueOf(v).setScale(6, RoundingMode.HALF_UP).stripTrailingZeros();
        return bd.toPlainString().replace('.', ',');
    }

    private double expressao() {
        double v = termo();
        while (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) {
            char op = s.charAt(i++);
            double d = termo();
            v = op == '+' ? v + d : v - d;
        }
        return v;
    }

    private double termo() {
        double v = potencia();
        while (i < s.length() && (s.charAt(i) == '*' || s.charAt(i) == '/')) {
            char op = s.charAt(i++);
            double d = potencia();
            v = op == '*' ? v * d : v / d;
        }
        return v;
    }

    private double potencia() {
        double base = unario();
        if (i < s.length() && s.charAt(i) == '^') {
            i++;
            return Math.pow(base, potencia()); // associa à direita
        }
        return base;
    }

    private double unario() {
        if (i < s.length() && s.charAt(i) == '-') {
            i++;
            return -unario();
        }
        if (i < s.length() && s.charAt(i) == '+') {
            i++;
            return unario();
        }
        return primario();
    }

    private double primario() {
        if (i < s.length() && s.charAt(i) == '(') {
            i++;
            double v = expressao();
            if (i >= s.length() || s.charAt(i) != ')') {
                throw new IllegalArgumentException("parêntese");
            }
            i++;
            return v;
        }
        int ini = i;
        while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.')) {
            i++;
        }
        if (ini == i) {
            throw new IllegalArgumentException("número esperado");
        }
        return Double.parseDouble(s.substring(ini, i));
    }
}
