package service;

/** A entrega de uma linha a uma conexão falhou (cliente caiu, socket fechado etc.). */
public class FalhaEnvioException extends RuntimeException {
    public FalhaEnvioException(String mensagem) {
        super(mensagem);
    }

    public FalhaEnvioException(String mensagem, Throwable causa) {
        super(mensagem, causa);
    }
}
